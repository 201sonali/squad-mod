Contents related to adding adversarial data to the pretrained model
